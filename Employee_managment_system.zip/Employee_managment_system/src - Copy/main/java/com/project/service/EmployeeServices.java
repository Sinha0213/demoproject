package com.project.service;
 import com.project.model.Employee;
 import java.util.List;
import java.util.Optional;

public interface EmployeeServices {
	
	public Employee addEmployee(Employee employee);
	 public String removeEmployee(int id);
	 public Optional<Employee> findEmpById(int id);
	 public List<Employee> getAllEmployee();
	 public String updateEmployee(int id);
	 
	

}

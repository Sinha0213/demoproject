package com.project.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.project.model.Employee;

public interface EmployeeRepos extends JpaRepository<Employee, Integer>{

	Employee save(Employee employee);

}
